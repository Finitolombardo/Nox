# PB-integration-google-workspace-gog.md

## Status
- Status: BROKEN
- Last checked: 2026-02-25 17:19:57 UTC
- Gmail Quick-Test (limit=1): `sudo -u agentadmin gog gmail search "in:inbox" --max=1 --json --no-input --account admin@alphamindhub.com` -> FAILED
- Drive Quick-Test (limit=1): `sudo -u agentadmin gog drive ls --max=1 --json --no-input --account admin@alphamindhub.com` -> FAILED
- Error (both): `OAuth client credentials missing (OAuth client ID JSON)... expected at /home/agentadmin/.config/gogcli/credentials.json`
- Evidence:
  - `sudo -u agentadmin gog --help` shows config path `/home/agentadmin/.config/gogcli/config.json`
  - `sudo -u agentadmin gog status --json --no-input` => `"credentials_exists": false`

## Scope
This playbook covers Google Workspace via the "gog" skill:
- Gmail
- Drive
- Sheets

## Quick-Tests
### Gmail Quick-Test
- Action: `sudo -u agentadmin gog gmail search "in:inbox" --max=1 --json --no-input --account <mail>`
- Expected: success (empty result allowed)

### Drive Quick-Test
- Action: `sudo -u agentadmin gog drive ls --max=1 --json --no-input --account <mail>`
- Expected: success

## Known-good configuration (NO secrets)
- credentials path: `/home/agentadmin/.config/gogcli/credentials.json`
- account configured in gog auth store

## Fix
1) Put OAuth client JSON at `/home/agentadmin/.config/gogcli/credentials.json`
2) `sudo -u agentadmin gog auth credentials /home/agentadmin/.config/gogcli/credentials.json`
3) `sudo -u agentadmin gog auth add admin@alphamindhub.com --services gmail,drive,sheets`
4) Re-run Gmail + Drive Quick-Tests

## Update policy
- Only set WORKING/BROKEN after tests run in this session.
- If test not executed: set UNVERIFIED with exact reason.
